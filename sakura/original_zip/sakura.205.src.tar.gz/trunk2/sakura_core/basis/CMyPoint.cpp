#include "StdAfx.h"
#include "CMyPoint.h"
