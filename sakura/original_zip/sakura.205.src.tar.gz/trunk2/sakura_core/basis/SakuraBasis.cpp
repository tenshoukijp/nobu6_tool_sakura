#include "StdAfx.h"
#include "SakuraBasis.h"
