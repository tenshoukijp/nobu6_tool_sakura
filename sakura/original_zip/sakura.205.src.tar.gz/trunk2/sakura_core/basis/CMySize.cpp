#include "StdAfx.h"
#include "CMySize.h"
