#include "StdAfx.h"
#include "types/CTypeSupport.h"
