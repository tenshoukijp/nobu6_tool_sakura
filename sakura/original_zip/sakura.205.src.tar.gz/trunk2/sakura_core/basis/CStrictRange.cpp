#include "StdAfx.h"
#include "CStrictRange.h"
