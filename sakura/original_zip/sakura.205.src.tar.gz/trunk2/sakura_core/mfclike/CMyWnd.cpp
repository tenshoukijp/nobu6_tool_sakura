#include "StdAfx.h"
#include "CMyWnd.h"
