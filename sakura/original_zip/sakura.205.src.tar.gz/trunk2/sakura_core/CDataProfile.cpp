#include "StdAfx.h"
#include "CDataProfile.h"
