#include "StdAfx.h"
#include "CStrictPoint.h"
