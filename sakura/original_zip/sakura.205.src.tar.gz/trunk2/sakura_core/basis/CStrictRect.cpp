#include "StdAfx.h"
#include "CStrictRect.h"
