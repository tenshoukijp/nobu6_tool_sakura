#include "StdAfx.h"
#include "CStrictInteger.h"

