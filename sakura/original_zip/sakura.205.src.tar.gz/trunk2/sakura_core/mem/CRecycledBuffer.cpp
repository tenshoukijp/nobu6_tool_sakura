#include "StdAfx.h"
#include "CRecycledBuffer.h"
