#include "StdAfx.h"
#include "CLaxInteger.h"

